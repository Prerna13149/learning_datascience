class episode:
	def __init__(self,s,a,r,t,s2):
		self.s = s
		self.a = a
		self.r = r
		self.t = t
		self.s2 = s2

class MinHeap:
		def __init__(self):
				s = [-0.02419576,0.17713837,0.02601037,-0.24089365]
				a = [0.08049148,0.08774105]
				r = 0.8648275251635911
				t = False
				s2 = [-0.020653,0.3718793,0.02119249,-0.52526005]

				self.heapList = [episode(s,a,r,t,s2)]
				self.currentSize = 0

		def percUp(self,i):
				while i // 2 > 0:
					if self.heapList[i].r < self.heapList[i // 2].r:
						 tmp = self.heapList[i // 2]
						 self.heapList[i // 2] = self.heapList[i]
						 self.heapList[i] = tmp
					i = i // 2

		def insert(self,k):
			self.heapList.append(k)
			self.currentSize = self.currentSize + 1
			self.percUp(self.currentSize)

		def percDown(self,i):
			while (i * 2) <= self.currentSize:
					mc = self.minChild(i)
					if self.heapList[i].r > self.heapList[mc].r:
							tmp = self.heapList[i]
							self.heapList[i] = self.heapList[mc]
							self.heapList[mc] = tmp
					i = mc

		def minChild(self,i):
			if i * 2 + 1 > self.currentSize:
					return i * 2
			else:
					if self.heapList[i*2].r < self.heapList[i*2+1].r:
							return i * 2
					else:
							return i * 2 + 1

		def delMin(self):
			retval = self.heapList[1]
			self.heapList[1] = self.heapList[self.currentSize]
			self.currentSize = self.currentSize - 1
			self.heapList.pop()
			self.percDown(1)
			return retval

		def getMin(self):
			retval = self.heapList[1]
			return retval

		def buildHeap(self,alist):
			i = len(alist) // 2
			self.currentSize = len(alist)
			self.heapList =  alist[:]
			while (i > 0):
					self.percDown(i)
					i = i - 1

		def print_heap(self):
			while self.currentSize!=0:
				minnode = bh.delMin()
				#print(minnode)


'''
bh = MinHeap()
al = []
for i in range(5):
	epi = episode(10-i,i**2,i**3)
	al.append(epi)
bh.buildHeap(al)

for i in range(len(al)):
	print(al[i].rt," ",al[i].at)

print("------------")

while bh.currentSize!=0:
	minnode = bh.delMin()
	print(minnode.rt," ",minnode.at)
'''
