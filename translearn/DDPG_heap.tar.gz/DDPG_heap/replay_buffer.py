"""
Data structure for implementing experience replay
Author: Patrick Emami
"""
from collections import deque
import random
import numpy as np
import min_heap_reward as min_heap

class ReplayBuffer(object):

    def __init__(self, buffer_size, random_seed=123):
        """
        The right side of the deque contains the most recent experiences
        """
        self.buffer_size = buffer_size
        self.count = 0
        self.buffer = min_heap.MinHeap()
        random.seed(random_seed)

    def add(self, s, a, r, t, s2):
        experience = min_heap.episode(s, a, r, t, s2)
        if self.count < self.buffer_size:
            self.buffer.insert(experience)
            self.count += 1
        else:
            #print(r)
            if(self.buffer.getMin() < r):
                self.buffer.delMin()
                self.buffer.insert(experience)

    def size(self):
        return self.count

    def sample_batch(self, batch_size):
        batch = []
        # print("current size : ",self.buffer.currentSize)
        # print("replay count : ",self.count)
        # print("batch size : ",batch_size)

        if self.count < batch_size:
            batch = random.sample(self.buffer.heapList, self.count)
        else:
            batch = random.sample(self.buffer.heapList, batch_size)
        
        # print(batch[1].s)
        # print(batch[1].a)
        # print(batch[1].r)
        # print(batch[1].t)
        # print(batch[1].s2)

        s_batch = np.array([x.s for x in batch])
        a_batch = np.array([x.a for x in batch])
        r_batch = np.array([x.r for x in batch])
        t_batch = np.array([x.t for x in batch])
        s2_batch = np.array([x.s2 for x in batch])
        #print("done")	
        return s_batch, a_batch, r_batch, t_batch, s2_batch

    def get_min(self):
        return self.buffer.getMin()

    def print_heap(self):
        self.buffer.print_heap()

